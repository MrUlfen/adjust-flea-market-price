// Load the configuration file
const config = require("./config.json");

class AdjustFleaMarketPrice {
    constructor() {
        this.mod = "adjust-flea-market-price";
    }

    postDBLoad(container) {
        console.log(`[${this.mod}] Applying Flea Market price multiplier: ${config.fleaMarketPriceMultiplier}`);

        const database = container.resolve("DatabaseServer").getTables();
        const fleaMarketPrices = database.templates.prices; // Make sure this is the correct path

        // Check if fleaMarketPrices is an object
        if (fleaMarketPrices && typeof fleaMarketPrices === 'object') {
            // Apply the multiplier to each item's Flea Market price
            for (const itemID in fleaMarketPrices) {
                const originalPrice = fleaMarketPrices[itemID];

                // Only adjust prices that are numeric
                if (typeof originalPrice === 'number') {
                    fleaMarketPrices[itemID] = Math.round(originalPrice * config.fleaMarketPriceMultiplier);
                    console.log(`[${this.mod}] Item ID: ${itemID}, Original Price: ${originalPrice}, New Price: ${fleaMarketPrices[itemID]}`);
                } else {
                    console.warn(`[${this.mod}] Skipping non-numeric price for item ID: ${itemID}`);
                }
            }

            console.log(`[${this.mod}] Flea Market prices adjusted by multiplier: ${config.fleaMarketPriceMultiplier}`);
        } else {
            console.error(`[${this.mod}] Failed to access flea market prices.`);
        }
    }
}

// Create an instance of the mod and export it with the correct interface
module.exports = {
    mod: new AdjustFleaMarketPrice(),
    __esModule: true,
    IPostDBLoadMod: true // Indicates that this mod implements IPostDBLoadMod
};
